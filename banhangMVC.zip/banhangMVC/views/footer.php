<!-- phan footer -->
<div class="footer">
                <div class="container">
                        <div class="row">
                             <div class="col-xl-3 col-12">
                                 <img src="./public/image/logo-trang.png" alt="">
                                 <p>Trang phục bạn khoác lên người chính là cách để bạn giới thiệu với mọi người về cá tính sống của mình. Do đó, việc lựa chọn dòng sản phẩm chất lượng chính là cách để bạn thể hiện giá trị bản thân mình.</p>
                                  <div class="img-fot">
                                      <img src="./public/image/footer1.png" alt="">&nbsp;
                                      <img src="./public/image/footer2.png" alt="">
                                  </div>
                             </div>
                             <div class="col-xl-3 col-12">
                                 <div class="hedd">
                                     <h5>HOYANG FASHION SHOP</h5>
                                 </div>
                                 <div class="hedd1">
                                     <span><b>Địa chỉ</b>: 936 Kha Vạn Cân, Trường Thọ, Thủ Đức, Hồ Chí Minh</span><br>
                                     <span><b>Bán lẻ</b>: 0772 211 168</span><br>
                                     <span><b>Bán sỉ</b>: 0796 753 366</span><br>
                                     <span><b>Zalo</b>: 0772 211 168 - 0796 753 366</span><br>
                                     <span><b>Email</b>: hoyangshop@gmail.com</span><br>
                                 </div>
                             </div>
                             <div class="col-xl-3 col-12">
                                <div class="hedd">
                                    <h5>HỖ TRỢ KHÁCH HÀNG</h5>
                                </div>
                                <ul class="list-fo">
                                      <li><a href="">Giới Thiệu Về HoYang</a></li>
                                      <li><a href="">Khách Hàng Thân Thiết</a></li> 
                                      <li><a href="">Hướng Dẫn Chọn Size</a></li> 
                                      <li><a href="">Bảo Hành Và Đổi Trả</a></li>   
                                      <li><a href="">Thanh Toán Và Vận Chuyển</a></li> 
                                      <li><a href="">Bảo Mật Thông Tin</a></li>
                                      <li><a href="">Liên Hệ</a></li>  
                                </ul>
                             </div>
                             <div class="col-xl-3 col-12">
                                    <div class="hedd">
                                        <h5>KẾT NỐI HOYANG</h5>
                                    </div>
                                    <div class="face">
                                        <div class="fb-page" data-href="https://www.facebook.com/xuong.may.hoyang/" data-tabs="timeline" data-width="270" data-height="130" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/xuong.may.hoyang/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/xuong.may.hoyang/">Xưởng May Quần Áo Thiết Kế HoYang</a></blockquote></div>
                                    </div>
                                   
                             </div>
                        </div>
                </div>
        </div>
    </div>

    <div class="modall">
        <div class="body">
                <div class="modall_hed">
                    <span>Hướng dẫn chọn size</span>
                    <button type="button" class="close">×</button>
                </div>
                <div class="modal_container">
                    <img src="./public/image/size.jpg" alt="">
                </div>
        </div>
    </div>  