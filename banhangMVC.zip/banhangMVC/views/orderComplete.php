<div class="jumbotron text-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Đặt hàng thành công</strong> cảm ơn bạn đã đặt hàng</p>
  <hr>
  <p>
    Having trouble? <a href="">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="?act=home" role="button">Về trang chủ</a>
  </p>
</div>
