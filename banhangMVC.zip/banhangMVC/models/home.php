<?php
require_once("model.php");
class home extends model{
    
}